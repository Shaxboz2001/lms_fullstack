# Bank AI Assistant
Ushbu chatdan foydalanishdan oldin postgresda init.sqlni ishlatish kerak. Bu pgAdminda yoki terminalda bo'lishi mumkin